import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class account_setting extends StatefulWidget {
  const account_setting({Key? key}) : super(key: key);

  @override
  State<account_setting> createState() => _account_settingState();
}

class _account_settingState extends State<account_setting> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.cyanAccent,
      ),
      body: 
      Column(

        children: [
          SizedBox(height: 10,),
          Text('Your Profile Picture',style: GoogleFonts.manrope(
        textStyle: Theme.of(context).textTheme.displayMedium,
        fontSize: 10,
        color: Colors.black38,
        fontWeight: FontWeight.w500,),
          ),
          SizedBox(height: 10,),
          Container(




            child: Column(
              children: [
                SizedBox(height: 15,),
                Icon(Icons.add_photo_alternate_outlined),
                Text('Upload Your photo',style: GoogleFonts.manrope(
                  textStyle: Theme.of(context).textTheme.displayMedium,
                  fontSize: 8,
                  color: Colors.black38,
                  fontWeight: FontWeight.w500,),)
              ],
            ),
          
          
          ),
          
          
            
          
        ],
      ),
    );
  }
}
