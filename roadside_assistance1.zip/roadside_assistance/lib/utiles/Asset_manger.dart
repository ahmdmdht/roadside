class AssetManger{

 static String baseImage = "assets/icons/";


 static  getImagePath(String ImageName){
    return baseImage+ImageName ;
  }

}